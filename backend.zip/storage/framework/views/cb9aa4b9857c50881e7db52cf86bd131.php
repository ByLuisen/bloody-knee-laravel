<!DOCTYPE html>
<html>
<head>
    <title>Detalles de tu pedido</title>
</head>
<body>
    <h1>Gracias por tu compra!</h1>
    <p>Aquí están los detalles de tu pedido:</p>
    <ul>
        <?php $__currentLoopData = $line_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item['description']); ?> - Cantidad: <?php echo e($item['quantity']); ?> - Precio: $<?php echo e($item['amount_total']/100); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <p>Total: $<?php echo e($checkout_session['amount_total']/100); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BLOODY-KNEE\backend\resources\views/mail/orders/shipped.blade.php ENDPATH**/ ?>